import sys,argparse
from pathlib import Path
sys.path.insert(0,'/home/runner/work/pi-agent-platform/pi-agent-platform/service/scripts/pi-qwen-load')
from watch_monitor import run_monitor
p=argparse.ArgumentParser();p.add_argument('--project');p.add_argument('--sha');p.add_argument('--deadline',type=float);p.add_argument('--root');p.add_argument('--out');a=p.parse_args();run_monitor(a.project,a.sha,a.deadline,a.root,a.out,[sys.executable,'/home/runner/work/_temp/load13/raw/monitor/tmpsy0xk13u/sampler.py'])
